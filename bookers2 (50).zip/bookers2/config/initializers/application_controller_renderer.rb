# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '3ad7881e548dc4e250add8990611e2ac7473fe79dbd86eb3ef2280fb7c6eabd4915e3d776cb93ffe5e37276871fe7885c98b5a65e335307a2ba5d714409850e3'
